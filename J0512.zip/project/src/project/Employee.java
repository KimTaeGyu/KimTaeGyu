package project;

public class Employee {
	private String empNo;
	private String name;
	private String part;
	
	public Employee() {}
	public Employee(String empNo, String name, String part)
	{
		this.empNo = empNo;
		this.name = name;
		this.part = part;
	}
	
	public String getEmpNo() { return this.empNo;}
	public String getname() { return this.name;}
	public String getpart() { return this.part;}
	public void setEmpNo(String empNo){ this.empNo=empNo;}
	public void setname(String name) { this.name=name;}
	public void setpart(String part) { this.part=part;}
	
	public void result()
	{
		System.out.println("��� : " + empNo);
		System.out.println("���� : " + name);
		System.out.println("�μ� : " + part);
	}
	
}
