package test3;

public class Main {

	public static void main(String[] args) {
		
		Hulk hulk = new Hulk();
		hulk.attack();
		hulk.heal(10);
		hulk.sound();
		hulk.attack();
		
		CaptinAmerica cap = new CaptinAmerica();
		cap.attack();
		cap.heal(10);
		cap.attack();
		cap.muster();
		cap.attack();
		

	}

}
