//0512 #3
//���� ��ũ ĸƾ�Ƹ޸�ī
package test3;

public interface hero {
	int MAX_HP = 100;
	
	
	void attack();
	void heal(int portion);
	default void sound() {
		
	}
}
